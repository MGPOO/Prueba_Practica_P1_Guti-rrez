import 'package:flutter/material.dart';
import 'about_screen.dart'; // Asegúrate de tener este archivo creado e importado
import '../utils/distance_calculator.dart';

class DistanceScreen extends StatefulWidget {
  const DistanceScreen({Key? key}) : super(key: key);

  @override
  _DistanceScreenState createState() => _DistanceScreenState();
}

class _DistanceScreenState extends State<DistanceScreen> {
  final TextEditingController x1Controller = TextEditingController();
  final TextEditingController y1Controller = TextEditingController();
  final TextEditingController x2Controller = TextEditingController();
  final TextEditingController y2Controller = TextEditingController();

  String result = '';
  String formula = 'Fórmula: √((x2 - x1)² + (y2 - y1)²)';
  String? x1Error, y1Error, x2Error, y2Error;

  void updateFormula() {
    final String x1Text = x1Controller.text;
    final String y1Text = y1Controller.text;
    final String x2Text = x2Controller.text;
    final String y2Text = y2Controller.text;

    if (_validateInputs(x1Text, y1Text, x2Text, y2Text)) {
      final double x1 = double.tryParse(x1Text) ?? 0;
      final double y1 = double.tryParse(y1Text) ?? 0;
      final double x2 = double.tryParse(x2Text) ?? 0;
      final double y2 = double.tryParse(y2Text) ?? 0;

      setState(() {
        formula = 'Fórmula: √((${x2.toStringAsFixed(1)} - ${x1.toStringAsFixed(1)})² + '
            '(${y2.toStringAsFixed(1)} - ${y1.toStringAsFixed(1)})²)';
      });
    } else {
      setState(() {
        formula = 'Fórmula: √((x2 - x1)² + (y2 - y1)²)';
      });
    }
  }

  bool _validateInputs(String x1, String y1, String x2, String y2) {
    setState(() {
      x1Error = _isNumeric(x1) ? null : 'Ingrese solo números enteros';
      y1Error = _isNumeric(y1) ? null : 'Ingrese solo números enteros';
      x2Error = _isNumeric(x2) ? null : 'Ingrese solo números enteros';
      y2Error = _isNumeric(y2) ? null : 'Ingrese solo números enteros';
    });

    return x1Error == null && y1Error == null && x2Error == null && y2Error == null;
  }

  bool _isNumeric(String value) {
    return double.tryParse(value) != null;
  }

  void calculateDistance() {
    final String x1Text = x1Controller.text;
    final String y1Text = y1Controller.text;
    final String x2Text = x2Controller.text;
    final String y2Text = y2Controller.text;

    if (_validateInputs(x1Text, y1Text, x2Text, y2Text)) {
      final double x1 = double.tryParse(x1Text) ?? 0;
      final double y1 = double.tryParse(y1Text) ?? 0;
      final double x2 = double.tryParse(x2Text) ?? 0;
      final double y2 = double.tryParse(y2Text) ?? 0;

      final distance = DistanceCalculator.calculateDistance(x1, y1, x2, y2);
      setState(() {
        result = 'La distancia es: ${distance.toStringAsFixed(2)} unidades';
      });
    } else {
      setState(() {
        result = 'Error: Corrija los campos marcados.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculadora de Distancia Euclideana'),
        backgroundColor: Colors.indigo,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: x1Controller,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Punto 1: x1',
                      errorText: x1Error,
                      border: const OutlineInputBorder(),
                    ),
                    onChanged: (_) => updateFormula(),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: y1Controller,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Punto 1: y1',
                      errorText: y1Error,
                      border: const OutlineInputBorder(),
                    ),
                    onChanged: (_) => updateFormula(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: x2Controller,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Punto 2: x2',
                      errorText: x2Error,
                      border: const OutlineInputBorder(),
                    ),
                    onChanged: (_) => updateFormula(),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: y2Controller,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Punto 2: y2',
                      errorText: y2Error,
                      border: const OutlineInputBorder(),
                    ),
                    onChanged: (_) => updateFormula(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              formula,
              style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: calculateDistance,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo),
              child: const Text('Calcular Distancia', style: TextStyle(color: Colors.black)),

            ),
            const SizedBox(height: 20),
            Text(
              result,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.indigo),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) =>  AboutScreen()),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              child: const Text('Acerca de', style: TextStyle(color: Colors.black)),

            ),
          ],
        ),
      ),
    );
  }
}
